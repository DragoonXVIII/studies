#include "meanbufor.h"

