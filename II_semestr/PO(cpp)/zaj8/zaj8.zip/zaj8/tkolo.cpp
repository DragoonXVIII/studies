
#include "Tpunkt.h"
#include "Tkolo.h"

#include "iostream"

using namespace std;

Tkolo::Tkolo()
{

}

Tkolo::~Tkolo()
{

}

int Tkolo::getR()
{
    return r;
}
