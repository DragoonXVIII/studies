package com.lab3;

public class Main 
{
    public static void main(String[] args) 
    {
        //System.out.println("Hello world!");
        class123.check("kurkuma",'k');
        System.out.println(class123.sumaASCII("aac"));
        //class123.IntToChar();
        System.out.println("");
        System.out.println(Cezar.cypherCezar("xyz"));
        System.out.println(Cezar.decypherCezar("abc"));
        System.out.println(Binary.intToBinaryString(2));
        System.out.println(Binary.zeroSequence("10010101101100101"));
        
    }

    
}