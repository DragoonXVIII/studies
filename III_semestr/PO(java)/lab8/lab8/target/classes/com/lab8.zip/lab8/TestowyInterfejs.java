package com.lab8;

public interface TestowyInterfejs 
{
 
    void abstrakcyjnaMetodaX();
 
}

