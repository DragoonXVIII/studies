package com.lab8;

/*
Napisz interfejs zawierający jedną metodę abstrakcyjną przyjmującą jako parametr 
łańcuch znaków. Stwórz listę (np. ArrayList) zawierającą spis przedmiotów do zaliczenia 
(klasa String). Napisz metodę przyjmującą jako parametry: listę łańcuchów znaków oraz 
stworzony interfejs – metoda ma wypisać wszystkie elementy listy. Użyj wyrażenia lambda 
przy wywołaniu metody.
 */

public interface zad1Interface 
{
     
     abstract void wyrLambda(String s);
    
} 
