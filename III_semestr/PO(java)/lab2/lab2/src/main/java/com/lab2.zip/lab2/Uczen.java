package com.lab2;

public class Uczen 
{
    String imie;
    String nazwisko;
    int wiek;
    double srednia;

    public Uczen() {}

    public Uczen(String imie, String nazwisko, int wiek, double srednia) 
    {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.wiek = wiek;
        this.srednia = srednia;
    }
}
