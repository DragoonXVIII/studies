package com.lab2;

public class Owoc 
{
    private String nazwa;
    private double masa;

    public Owoc(String nazwa, double masa) 
    {
        this.nazwa = nazwa;
        this.masa = masa;
    }

    public String getNazwa() 
    {
        return nazwa;
    }

    public double getMasa() 
    {
        return masa;
    }
}

