package com.lab2;

public class MetodaStatyczna 
{
    public static void wypiszWartosci() 
    {
        for (int i = 0; i <= 54; i++) 
        {
            System.out.println(i);
        }
    }
}